package com.example.epoch;

import javax.servlet.ServletException;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.startup.Tomcat;

public class EpochApplication {
    public static void main(String[] args) {
        // Set the port number
        int port = 8080;

        // Create and start Tomcat server
        Tomcat tomcat = new Tomcat();
        tomcat.setPort(port);

        try {
            tomcat.getConnector(); // triggers creation of default connector
            
            // Add web application
            String webappDirLocation = "src/main/webapp/";
            tomcat.addWebapp("/epoch-1.0-SNAPSHOT", webappDirLocation); // Adjusted the context path
            
            // Start the server
            tomcat.start();
            System.out.println("Server started at http://localhost:" + port + "/epoch-1.0-SNAPSHOT");
            
            // Add shutdown hook
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try {
                    tomcat.stop();
                    tomcat.destroy();
                    System.out.println("Server stopped.");
                } catch (LifecycleException e) {
                    e.printStackTrace();
                }
            }));
            
            tomcat.getServer().await();
        } catch (LifecycleException e) {
            e.printStackTrace();
            System.err.println("Failed to start the server: " + e.getMessage());
        }
    }
}
