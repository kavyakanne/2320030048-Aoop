package com.example.epoch;

import java.io.Serializable;

public class Blog implements Serializable {
    private static final long serialVersionUID = 1L; // Serializable version ID
    private int id;
    private String title;
    private String content;

    public Blog() {
    }

    public Blog(int id, String title, String content) {
        this.id = id;
        setTitle(title); // Use setter for validation
        setContent(content); // Use setter for validation
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Title cannot be null or empty");
        }
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        if (content == null || content.trim().isEmpty()) {
            throw new IllegalArgumentException("Content cannot be null or empty");
        }
        this.content = content;
    }

    @Override
    public String toString() {
        return "Blog{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
