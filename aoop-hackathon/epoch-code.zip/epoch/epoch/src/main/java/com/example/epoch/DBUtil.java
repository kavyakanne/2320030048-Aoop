package com.example.epoch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBUtil {
    private static final String URL = "jdbc:postgresql://localhost:5432/epoch"; // Update with your DB name
    private static final String USER = "postgres"; // Your DB username
    private static final String PASSWORD = "postgre"; // Your DB password
    private static final Logger logger = Logger.getLogger(DBUtil.class.getName());

    // Method to get a database connection
    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error getting database connection", e);
            throw new RuntimeException("Error connecting to the database", e);
        }
    }

    // Method to update a record in the database
    public static int updateRecord(int id, String newTitle) {
        String updateSQL = "UPDATE posts SET title = ? WHERE id = ?";
        int affectedRows = 0;

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(updateSQL)) {
             
            pstmt.setString(1, newTitle);
            pstmt.setInt(2, id);
            affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                logger.info("Update successful for ID: " + id);
            } else {
                logger.warning("No record found with ID: " + id);
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error updating record", e);
        }
        
        return affectedRows;
    }

    // Method to insert a new record into the database
    public static int insertRecord(String title) {
        String insertSQL = "INSERT INTO posts (title) VALUES (?)";
        int affectedRows = 0;

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
             
            pstmt.setString(1, title);
            affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                logger.info("Insert successful for title: " + title);
            } else {
                logger.warning("Insert failed for title: " + title);
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error inserting record", e);
        }
        
        return affectedRows;
    }
}
