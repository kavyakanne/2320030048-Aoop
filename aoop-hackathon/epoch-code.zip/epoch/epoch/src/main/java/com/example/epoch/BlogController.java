package com.example.epoch;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/blogs")
public class BlogController extends HttpServlet {
    private ExecutorService executorService = Executors.newFixedThreadPool(10); // Thread pool

    @Override
    public void destroy() {
        executorService.shutdown(); // Shutdown executor service on destruction
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String content = request.getParameter("content");

        if (title == null || content == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Title and content are required.");
            return;
        }

        // Creating a new blog in a separate thread
        executorService.submit(() -> createBlog(new Blog(0, title, content)));

        response.sendRedirect("index.jsp");
    }

    private void createBlog(Blog blog) {
        String sql = "INSERT INTO blogs (title, content) VALUES (?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, blog.getTitle());
            stmt.setString(2, blog.getContent());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Consider using a logging framework
        }
    }

    private List<Blog> readBlogs() throws SQLException {
        List<Blog> blogs = new ArrayList<>();
        String sql = "SELECT * FROM blogs";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Blog blog = new Blog();
                blog.setId(rs.getInt("id"));
                blog.setTitle(rs.getString("title"));
                blog.setContent(rs.getString("content"));
                blogs.add(blog);
            }
        }
        return blogs;
    }

    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id;
        try {
            id = Integer.parseInt(request.getParameter("id"));
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid blog ID.");
            return;
        }

        String title = request.getParameter("title");
        String content = request.getParameter("content");

        if (title == null || content == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Title and content are required.");
            return;
        }

        executorService.submit(() -> updateBlog(new Blog(id, title, content)));
        response.sendRedirect("index.jsp");
    }

    private void updateBlog(Blog blog) {
        String sql = "UPDATE blogs SET title = ?, content = ? WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, blog.getTitle());
            stmt.setString(2, blog.getContent());
            stmt.setInt(3, blog.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Consider using a logging framework
        }
    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id;
        try {
            id = Integer.parseInt(request.getParameter("id"));
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid blog ID.");
            return;
        }

        executorService.submit(() -> deleteBlog(id));
        response.sendRedirect("index.jsp");
    }

    private void deleteBlog(int id) {
        String sql = "DELETE FROM blogs WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Consider using a logging framework
        }
    }
}
